#include "cWheel.h"

Wheel::Wheel()
{
	x = y = z = 0;
	r = g = b = 1;
	rotX = 0;
}

Wheel::Wheel(float _x, float _y, float _z,
	float _r, float _g, float _b)
{
	x = _x;	y = _y;	z = _z;
	r = _r;	g = _g;	b = _b;
	rotX = 0;
}

Wheel::~Wheel()
{
}

void Wheel::draw()
{
	glPushMatrix();
	{
		glColor3f(r, g, b);
		glTranslatef(x, y, z);
		glRotatef(rotX, 1, 0, 0);
		glScalef(0.2, 1, 1);
		glutWireSphere(1, 10, 10);
	}
	glPopMatrix();
}

void Wheel::update()
{
	rotX += 0.1f;
}