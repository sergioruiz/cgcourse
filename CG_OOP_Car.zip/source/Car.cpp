#include "Car.h"

Car::Car()
{
	for (int i = 0; i < 4; i++)
	{
		wheels[i] = new Wheel();
	}
	wheels[0]->x = -1;
	wheels[0]->z = 2;
	wheels[1]->x = 1;
	wheels[1]->z = 2;
	wheels[2]->x = 1;
	wheels[2]->z = -2;
	wheels[3]->x = -1;
	wheels[3]->z = -2;
}

Car::~Car()
{
}

void Car::draw()
{
	glPushMatrix();
	{
		glColor3f(1, 0, 0);
		glScalef(1, 1, 5);
		glutSolidCube(1);
	}
	glPopMatrix();
	for (int i = 0; i < 4; i++)
	{
		wheels[i]->draw();
	}
}

void Car::update()
{
	for (int i = 0; i < 4; i++)
	{
		wheels[i]->update();
	}
}