#pragma once
class Point
{
public:
	Point();
	Point(int _vi, int _ti, int _ni, float _x, float _y, float _z, float _u, float _v, float _nx, float _ny, float _nz);
	~Point();

	int vi;
	int ti;
	int ni;
	float x, y, z;		// vertex location
	float u, v;			// texture coordinates
	float nx, ny, nz;	// normal
};
