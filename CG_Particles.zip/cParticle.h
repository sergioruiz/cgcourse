#pragma once
#ifdef __APPLE__
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#include <GLUT/glut.h>
#else
#include "freeglut.h"
#endif

#include "cVector3.h"  // create the class

#ifndef __PARTICLE
#define __PARTICLE
class Particle
{
public:
	Particle(Vector3* _position, float _radius);
	~Particle();

	void draw();
	void update(float dt);
	void VerletIntegration(float dt);
	bool checkCollision(Particle* another);

	float mass;
	float radius;
	Vector3* position;
	Vector3* prev_pos;
	Vector3* forces;
	Vector3* dragForce;

};
#endif // __PARTICLE