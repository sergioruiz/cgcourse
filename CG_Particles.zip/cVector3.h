#pragma once
#include <stdio.h>
#ifndef __VECTOR3
#define __VECTOR3
class Vector3
{
public:
	Vector3();
	Vector3(Vector3* other);
	Vector3(float _x, float _y, float _z);
	~Vector3();

	void print();

	float x, y, z;
};
#endif //__VECTOR3
