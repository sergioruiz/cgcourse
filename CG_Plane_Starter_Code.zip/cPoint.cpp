#include "cPoint.h"

Point::Point()
{
	x = y = z = u = v = nx = ny = nz = 0;
}

Point::Point(float _x, float _y, float _z, float _u, float _v, float _nx, float _ny, float _nz)
{
	x = _x;
	y = _y;
	z = _z;
	u = _u;
	v = _v;
	nx = _nx;
	ny = _ny;
	nz = _nz;
}

Point::~Point()
{
}
