#include "cPlane.h"

Plane::Plane(int tWidth, int tHeight, int hCuts, int vCuts)
{
		   //X  Y  Z  U  V nX nY nZ
	Point v1(0, 0, 0, 0, 0, 0, 1, 0);
	Point v2(1, 0, 0, 1, 0, 0, 1, 0);
	Point v3(1, 1, 0, 0, 0, 0, 1, 0);
	vertices.push_back(v1);
	vertices.push_back(v2);
	vertices.push_back(v3);
	
	Face f1;
	f1.v1 = v1;
	f1.v2 = v2;
	f1.v3 = v3;
	faces.push_back(f1);
}

Plane::~Plane()
{
}

void Plane::exportToOBJ(char* filename)
{
	objFile.open(filename);
	objFile << "v " << ((Point)vertices[0]).x;
	objFile << " ";
	objFile << ((Point)vertices[0]).y;
	objFile << " ";
	objFile << ((Point)vertices[0]).z;
	objFile << endl;

	objFile.close();
}
