#pragma once

#include <iostream>
#include <fstream>
#include <vector>
// http://www.cplusplus.com/reference/vector/vector/vector/
#include "cPoint.h"
using namespace std;

struct Face
{
	Point v1;
	Point v2;
	Point v3;
};

#ifndef __PLANE
#define __PLANE
class Plane
{
public:
	Plane(int tWidth, int tHeight, int hCuts, int vCuts);
	~Plane();
	void exportToOBJ(char* filename);

	ofstream objFile;
	int total_width;
	int total_height;
	int horizontal_cuts;
	int vertical_cuts;
	vector<Point> vertices;
	vector<Face> faces;
};
#endif //__PLANE