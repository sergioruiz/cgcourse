#include "ATST.h"

ATST::ATST()
{
	for (int i = 0; i < NUMBLOCKS; i++)
	{
		blocks[i] = new Block();
		blocks[i]->r = 0.5f;
		blocks[i]->g = 0.5f;
		blocks[i]->b = 0.5f;
	}
	blocks[L_FOOT]->sX = 1.0f;
	blocks[L_FOOT]->sY = 0.2f;
	blocks[L_FOOT]->sZ = 1.0f;

	blocks[R_FOOT]->sX = 1.0f;
	blocks[R_FOOT]->sY = 0.2f;
	blocks[R_FOOT]->sZ = 1.0f;

	blocks[L_CALF]->sX = 0.6f;
	blocks[L_CALF]->sY = 2.0f;
	blocks[L_CALF]->sZ = 0.6f;

	blocks[R_CALF]->sX = 0.6f;
	blocks[R_CALF]->sY = 2.0f;
	blocks[R_CALF]->sZ = 0.6f;

}

void ATST::draw()
{
	glPushMatrix();
	{
		glTranslatef(-2.0f, 0, 0);
		blocks[L_FOOT]->draw();
		glTranslatef(0, 1, 0);
		blocks[L_CALF]->draw();
	}
	glPopMatrix();

	glPushMatrix();
	{
		glTranslatef(2.0f, 0, 0);
		blocks[R_FOOT]->draw();
		glTranslatef(0, 1, 0);
		blocks[R_CALF]->draw();
	}
	glPopMatrix();

}

void ATST::update()
{

}

ATST::~ATST()
{
}
