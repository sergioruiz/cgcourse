#pragma once

#ifdef __APPLE__
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#include <GLUT/glut.h>
#else
#include "freeglut.h"
#endif

#include "cPoint.h"
#include <stdio.h>
#include <math.h>

class Point
{
public:
	Point();
	Point(float _x, float _y, float _z, float _r, float _g, float _b, float _radius);
	~Point();

	void draw();

	float x;
	float y;
	float z;
	float r;
	float g;
	float b;
	float radius;
};

