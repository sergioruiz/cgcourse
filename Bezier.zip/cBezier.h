#pragma once
#ifdef __APPLE__
	#include <OpenGL/gl.h>
	#include <OpenGL/glu.h>
	#include <GLUT/glut.h>
#else
	#include "freeglut.h"
#endif

#include "cPoint.h"
#include <stdio.h>
#include <math.h>
class Bezier
{
public:
	Bezier(int degree, Point* p, int ePoints);
	~Bezier();

	float binomial(int n, int i);
	int factorial(int x);
	void calcCoefficients();
	Point* evalBezier(float t);

	void draw();

	int n;
	int evalPoints;
	float* coefficients;
	Point* points;
};

