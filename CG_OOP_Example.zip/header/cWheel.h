#pragma once	// Compiler directive
#ifdef __APPLE__
// See: http://lnx.cx/docs/opengl-in-xcode/
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#include <GLUT/glut.h>
#include <stdlib.h>
#else
#include "freeglut.h"
#endif
#include <stdio.h>
#include <math.h>

class Wheel
{
public:
	Wheel(float _x, float _y, float _z, float _r, float _g, float _b);	// Constructor
	~Wheel();	// Deconstructor or Destroyer

	void draw();	// Like display
	void update();	// Like idle

	float x;	// position
	float y;	// position
	float z;	// position

	float r, g, b; // color
	float rotX;
};

