/*
	TC3022. Computer Graphics

	Basic lighting example 4.
	Displays two shaded spheres.
		-Source 1: spot.
		-Global ambient source.
*/

#ifdef __APPLE__
	#include <OpenGL/gl.h>
	#include <OpenGL/glu.h>
	#include <GLUT/glut.h>
#else
	#include "freeglut.h"
#endif

GLfloat		rotation;
GLfloat*	mat0_specular; //<---------------------------------------Material 0 - especular
GLfloat*	mat0_diffuse; //<----------------------------------------Material 0 - difuso
GLfloat*	mat0_ambient; //<----------------------------------------Material 0 - ambiente
GLfloat*	mat0_shininess; //<--------------------------------------Material 0 - brillo

GLfloat*	mat1_specular; //<---------------------------------------Material 1 - especular
GLfloat*	mat1_diffuse; //<----------------------------------------Material 1 - difuso
GLfloat*	mat1_ambient; //<----------------------------------------Material 1 - ambiente
GLfloat*	mat1_shininess; //<--------------------------------------Material 1 - brillo

GLfloat*	spot0_position; //<--------------------------------------Luz 0 - posici�n
GLfloat*	spot0_diffuse; //<---------------------------------------Luz 0 - difuso
GLfloat*	spot0_specular; //<--------------------------------------Luz 0 - especular
GLfloat*	spot0_ambient; //<---------------------------------------Luz 0 - ambiente
GLfloat*	spot0_direction; //<-------------------------------------Luz 0 - direcci�n del cono de luz
GLfloat		spot0_att_constant; //<----------------------------------Luz 0 - atenuaci�n constante
GLfloat		spot0_att_linear; //<------------------------------------Luz 0 - atenuaci�n lineal
GLfloat		spot0_att_quadratic; //<---------------------------------Luz 0 - atenuaci�n cuadr�tica
GLfloat		spot0_exponent; //<--------------------------------------Luz 0 - exponente del spot
GLfloat		spot0_cutoff; //<----------------------------------------Luz 0 - �ngulo de corte del spot

GLfloat*	global_ambient; //<--------------------------------------Ambiente global
//
//----------------------------------------------------------------------------------------------
//
/*
	Funci�n para inicializar variables del programa.
*/
void init( void )
{
	glClearColor ( 0.0f, 0.0f, 0.0f, 0.0f ); //<---------------------'Borrar' pantalla
	glShadeModel ( GL_SMOOTH ); //<----------------------------------Indicar sombreado suave

//->Inicia definir material 0
	mat0_specular		= new GLfloat[4]; //<------------------------Asignar memoria
	mat0_specular[0]	= 1.0f; //<----------------------------------S0r
	mat0_specular[1]	= 0.2f; //<----------------------------------S0g
	mat0_specular[2]	= 1.0f; //<----------------------------------S0b
	mat0_specular[3]	= 1.0f; //<----------------------------------S0a

	mat0_diffuse		= new GLfloat[4]; //<------------------------Asignar memoria
	mat0_diffuse[0]		= 1.0f; //<----------------------------------D0r
	mat0_diffuse[1]		= 0.0f; //<----------------------------------D0g
	mat0_diffuse[2]		= 1.0f; //<----------------------------------D0b
	mat0_diffuse[3]		= 1.0f; //<----------------------------------D0a

	mat0_ambient		= new GLfloat[4]; //<------------------------Asignar memoria
	mat0_ambient[0]		= 0.1f; //<----------------------------------A0r
	mat0_ambient[1]		= 0.0f; //<----------------------------------A0g
	mat0_ambient[2]		= 0.1f; //<----------------------------------A0b
	mat0_ambient[3]		= 1.0f; //<----------------------------------A0a

	mat0_shininess		= new GLfloat[1]; //<------------------------Asignar memoria
	mat0_shininess[0]	= 60.0f; //<---------------------------------Brillo del material 0
//<-Termina definir material 0

//->Inicia definir material 1
	mat1_specular		= new GLfloat[4]; //<------------------------Asignar memoria
	mat1_specular[0]	= 0.1f; //<----------------------------------S1r
	mat1_specular[1]	= 0.5f; //<----------------------------------S1g
	mat1_specular[2]	= 0.1f; //<----------------------------------S1b
	mat1_specular[3]	= 1.0f; //<----------------------------------S1a

	mat1_diffuse		= new GLfloat[4]; //<------------------------Asignar memoria
	mat1_diffuse[0]		= 0.0f; //<----------------------------------D1r
	mat1_diffuse[1]		= 1.0f; //<----------------------------------D1g
	mat1_diffuse[2]		= 0.0f; //<----------------------------------D1b
	mat1_diffuse[3]		= 1.0f; //<----------------------------------D1a

	mat1_ambient		= new GLfloat[4]; //<------------------------Asignar memoria
	mat1_ambient[0]		= 0.0f; //<----------------------------------A1r
	mat1_ambient[1]		= 0.1f; //<----------------------------------A1g
	mat1_ambient[2]		= 0.0f; //<----------------------------------A1b
	mat1_ambient[3]		= 1.0f; //<----------------------------------A1a

	mat1_shininess		= new GLfloat[1]; //<------------------------Asignar memoria
	mat1_shininess[0]	= 20.0f; //<---------------------------------Brillo del material 1
//<-Termina definir material 1

//->Inicia definir luz 0
	spot0_position		= new GLfloat[4]; //<------------------------Asignar memoria
	spot0_position[0]	=  0.0f; //<---------------------------------L0x
	spot0_position[1]	=  2.0f; //<---------------------------------L0y
	spot0_position[2]	=  0.0f; //<---------------------------------L0z
	spot0_position[3]	=  1.0f; //<---------------------------------L0w

	spot0_specular		= new GLfloat[4]; //<------------------------Asignar memoria
	spot0_specular[0]	= 1.0f; //<----------------------------------L0Sr
	spot0_specular[1]	= 1.0f; //<----------------------------------L0Sg
	spot0_specular[2]	= 1.0f; //<----------------------------------L0Sb
	spot0_specular[3]	= 1.0f; //<----------------------------------L0Sa

	spot0_diffuse		= new GLfloat[4]; //<------------------------Asignar memoria
	spot0_diffuse[0]	= 1.0f; //<----------------------------------L0Dr
	spot0_diffuse[1]	= 0.9f; //<----------------------------------L0Dg
	spot0_diffuse[2]	= 0.9f; //<----------------------------------L0Db
	spot0_diffuse[3]	= 1.0f; //<----------------------------------L0Da

	spot0_ambient		= new GLfloat[4]; //<------------------------Asignar memoria
	spot0_ambient[0]	= 0.1f; //<----------------------------------L0Ar
	spot0_ambient[1]	= 0.1f; //<----------------------------------L0Ag
	spot0_ambient[2]	= 0.1f; //<----------------------------------L0Ab
	spot0_ambient[3]	= 1.0f; //<----------------------------------L0Aa

	spot0_direction		= new GLfloat[3];
	spot0_direction[0]	=  0.0f;
	spot0_direction[1]	= -1.0f;
	spot0_direction[2]	=  0.0f;

	spot0_att_constant	= 0.2f;
	spot0_att_linear	= 0.2f;
	spot0_att_quadratic = 0.2f;

	spot0_exponent		= 2.0f;
	spot0_cutoff		= 45.0f;
//<-Termina definir luz 0

// Configurar LUZ 0:
	glLightfv( GL_LIGHT0, GL_POSITION,				spot0_position		);
	glLightfv( GL_LIGHT0, GL_AMBIENT,				spot0_ambient		);
	glLightfv( GL_LIGHT0, GL_DIFFUSE,				spot0_diffuse		);
	glLightfv( GL_LIGHT0, GL_SPECULAR,				spot0_specular		);
	glLightf ( GL_LIGHT0, GL_CONSTANT_ATTENUATION,	spot0_att_constant	);
	glLightf ( GL_LIGHT0, GL_LINEAR_ATTENUATION,	spot0_att_linear	);
	glLightf ( GL_LIGHT0, GL_QUADRATIC_ATTENUATION, spot0_att_quadratic	);
	glLightf ( GL_LIGHT0, GL_SPOT_CUTOFF,			spot0_cutoff		);
	glLightfv( GL_LIGHT0, GL_SPOT_DIRECTION,		spot0_direction		);
	glLightf ( GL_LIGHT0, GL_SPOT_EXPONENT,			spot0_exponent		);

// Configurar modelo de iluminaci�n:
	global_ambient		= new GLfloat[4];
	global_ambient[0]	= 0.5f;
	global_ambient[1]	= 0.5f;
	global_ambient[2]	= 0.5f;
	global_ambient[3]	= 1.0f;
	glLightModelfv( GL_LIGHT_MODEL_AMBIENT, global_ambient ); //<----Luz ambiental para toda la escena
	glLightModeli( GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE ); //<-------Calcular especulares respecto a un punto de vista infinito
	glLightModeli( GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE ); //<-----------Calcular iluminaci�n al frente y al reverso de los objetos
// Habilitar LUZ 0:
	glEnable( GL_LIGHT0 );
// Habilitar iluminaci�n:
	glEnable( GL_LIGHTING );
// Habilitar prueba de profundidad (distinguir entre caras cercanas y lejanas):
	glEnable( GL_DEPTH_TEST );
// Asignar �ngulo de rotaci�n inicial:
	rotation = 0.0f;
}
//
//----------------------------------------------------------------------------------------------
//
/*
	Callback a llamar cuando la ventana cambia de dimensiones.
*/
void display( void )
{
// Limpiar los buffers de color y de profundidad:
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
// Dibujar los pol�gonos:
	glPushMatrix();
		glRotatef( rotation, 0.0f, 1.0f, 1.0f );
// Indicar propiedades del material con el que vamos a dibujar:
		glMaterialfv( GL_FRONT,  GL_AMBIENT,   mat0_ambient		);
		glMaterialfv( GL_FRONT,	 GL_DIFFUSE,   mat0_diffuse		);
		glMaterialfv( GL_FRONT,  GL_SPECULAR,  mat0_specular	);
		glMaterialfv( GL_FRONT,  GL_SHININESS, mat0_shininess	);
		glPushMatrix();
			glTranslatef( 1.0f, 0.0f, 0.0f );
			glutSolidSphere( 0.5, 40, 40 );
		glPopMatrix();
// Indicar propiedades del material con el que vamos a dibujar:
		glMaterialfv( GL_FRONT,  GL_AMBIENT,   mat1_ambient		);
		glMaterialfv( GL_FRONT,	 GL_DIFFUSE,   mat1_diffuse		);
		glMaterialfv( GL_FRONT,  GL_SPECULAR,  mat1_specular	);
		glMaterialfv( GL_FRONT,  GL_SHININESS, mat1_shininess	);
		glPushMatrix();
			glTranslatef( -1.0f, 0.0f, 0.0f );
			glutSolidSphere( 0.5, 40, 40 );
		glPopMatrix();
	glPopMatrix();
// Intercambiar el buffer visible por el oculto:
	glutSwapBuffers();
}
//
//----------------------------------------------------------------------------------------------
//
/*
	Callback a llamar cuando se ha terminado de dibujar.
*/
void idle( void )
{
	rotation += 0.02f;
	if( rotation > 360.0f )
	{
		rotation = 0.0f;
	}
	glutPostRedisplay();
}
//
//----------------------------------------------------------------------------------------------
//
/*
	Callback a llamar cuando la ventana cambia de dimensiones.
*/
void reshape( int w, int h )
{
// Dimensionar la ventana de acuerdo a las nuevas medidas:
	glViewport( 0, 0, (GLsizei) w, (GLsizei) h );
// Activar el modo de proyecci�n:
	glMatrixMode( GL_PROJECTION );
// Cargar la matriz identidad en la matriz actual de proyecci�n:
	glLoadIdentity();
// Ajustar el frustum a las nuevas medidas:
	if( w <= h )
	{
		glOrtho(- 1.5, 
				  1.5, 
				- 1.5 * (GLfloat)h / (GLfloat)w,
				  1.5 * (GLfloat)h / (GLfloat)w,
				-10.0,
				 10.0							);
	}
	else
	{
	    glOrtho(- 1.5 * (GLfloat)w / (GLfloat)h,
				  1.5 * (GLfloat)w / (GLfloat)h,
			    - 1.5,
				  1.5,
			    -10.0,
			     10.0							);
	}
// Activar el modo de Modelo-Vista:
	glMatrixMode( GL_MODELVIEW );
// Cargar la matriz identidad en la matriz actual de modelo-vista:
	glLoadIdentity();
}
//
//----------------------------------------------------------------------------------------------
//
/*
	Funci�n principal.
	Inicializa GLUT y ejecuta la rutina de despliegue.
*/
int main( int argc, char** argv )
{
// Inicializar GLUT:
	glutInit( &argc, argv );
// Inicializar modo de despliegue, usar 2 buffers, usar 3 canales
// de color, y usar el buffer de profundidad:
	glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH );
// Inicializar el tama�o de la ventana:
	glutInitWindowSize( 500, 500 );
// Inicializar la posici�n de la ventana:
	glutInitWindowPosition( 100, 100 );
// Desplegar la ventana (El t�tulo es el primer argumento recibido,
// es decir, el 'path' del archivo ejecutable para este programa):
	glutCreateWindow( argv[0] );
// Ejecutar la funci�n 'init':
	init();
// Registrar 'callbacks':
	glutDisplayFunc( display ); 
	glutReshapeFunc( reshape );
	glutIdleFunc( idle );
// Inicia render:
	glutMainLoop();
// ANSI C requiere el retorno de un entero, generalmente
// 0 si todo sali� bien, y otro entero si hay error.
	return 0;
}
//
//----------------------------------------------------------------------------------------------
//
