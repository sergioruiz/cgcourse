/*
	TC3022. Computer Graphics

	Basic lighting example 3.
	Displays two shaded spheres.
		-Source 1: spot.
*/

#ifdef __APPLE__
	#include <OpenGL/gl.h>
	#include <OpenGL/glu.h>
	#include <GLUT/glut.h>
#else
	#include "freeglut.h"
#endif

GLfloat		rotation;
GLfloat*	mat0_specular; //<---------------------------------------Material 0 - specular
GLfloat*	mat0_diffuse; //<----------------------------------------Material 0 - diffuse
GLfloat*	mat0_ambient; //<----------------------------------------Material 0 - ambient
GLfloat*	mat0_shininess; //<--------------------------------------Material 0 - shininess

GLfloat*	mat1_specular; //<---------------------------------------Material 1 - specular
GLfloat*	mat1_diffuse; //<----------------------------------------Material 1 - diffuse
GLfloat*	mat1_ambient; //<----------------------------------------Material 1 - ambient
GLfloat*	mat1_shininess; //<--------------------------------------Material 1 - shininess

GLfloat*	spot0_position; //<--------------------------------------Light 0 - location
GLfloat*	spot0_diffuse; //<---------------------------------------Light 0 - diffuse
GLfloat*	spot0_specular; //<--------------------------------------Light 0 - specular
GLfloat*	spot0_ambient; //<---------------------------------------Light 0 - ambient
GLfloat*	spot0_direction; //<-------------------------------------Light 0 - light cone direction
GLfloat		spot0_att_constant; //<----------------------------------Light 0 - constant attenuation
GLfloat		spot0_att_linear; //<------------------------------------Light 0 - linear attenuation
GLfloat		spot0_att_quadratic; //<---------------------------------Light 0 - quadratic attenuation
GLfloat		spot0_exponent; //<--------------------------------------Light 0 - spotlight power
GLfloat		spot0_cutoff; //<----------------------------------------Light 0 - spot cutting angle

/*
									1
	Attenuation factor   =  --------------------
							 Kc + Kl*d + Kq*d^2

	Where:
		-Kc = constant attenuation.
		-Kl = linear attenuation.
		-Kq = quadratic attenuation.
		-d  = distance from the light source to the vertex.
	*For a directional light, attenuation factor is 1.
*/

//
//----------------------------------------------------------------------------------------------
//
void init( void )
{
	glClearColor ( 0.0f, 0.0f, 0.0f, 0.0f );
	glShadeModel ( GL_SMOOTH );

	mat0_specular		= new GLfloat[4]; //<------------------------Reserve memory
	mat0_specular[0]	= 1.0f; //<----------------------------------S0r
	mat0_specular[1]	= 0.2f; //<----------------------------------S0g
	mat0_specular[2]	= 0.2f; //<----------------------------------S0b
	mat0_specular[3]	= 1.0f; //<----------------------------------S0a

	mat0_diffuse		= new GLfloat[4]; //<------------------------Reserve memory
	mat0_diffuse[0]		= 1.0f; //<----------------------------------D0r
	mat0_diffuse[1]		= 0.0f; //<----------------------------------D0g
	mat0_diffuse[2]		= 0.0f; //<----------------------------------D0b
	mat0_diffuse[3]		= 1.0f; //<----------------------------------D0a

	mat0_ambient		= new GLfloat[4]; //<------------------------Reserve memory
	mat0_ambient[0]		= 0.1f; //<----------------------------------A0r
	mat0_ambient[1]		= 0.0f; //<----------------------------------A0g
	mat0_ambient[2]		= 0.0f; //<----------------------------------A0b
	mat0_ambient[3]		= 1.0f; //<----------------------------------A0a

	mat0_shininess		= new GLfloat[1]; //<------------------------Reserve memory
	mat0_shininess[0]	= 60.0f; //<---------------------------------shininess for material 0


	mat1_specular		= new GLfloat[4]; //<------------------------Reserve memory
	mat1_specular[0]	= 0.1f; //<----------------------------------S1r
	mat1_specular[1]	= 0.1f; //<----------------------------------S1g
	mat1_specular[2]	= 0.5f; //<----------------------------------S1b
	mat1_specular[3]	= 1.0f; //<----------------------------------S1a

	mat1_diffuse		= new GLfloat[4]; //<------------------------Reserve memory
	mat1_diffuse[0]		= 0.0f; //<----------------------------------D1r
	mat1_diffuse[1]		= 0.0f; //<----------------------------------D1g
	mat1_diffuse[2]		= 1.0f; //<----------------------------------D1b
	mat1_diffuse[3]		= 1.0f; //<----------------------------------D1a

	mat1_ambient		= new GLfloat[4]; //<------------------------Reserve memory
	mat1_ambient[0]		= 0.0f; //<----------------------------------A1r
	mat1_ambient[1]		= 0.0f; //<----------------------------------A1g
	mat1_ambient[2]		= 0.1f; //<----------------------------------A1b
	mat1_ambient[3]		= 1.0f; //<----------------------------------A1a

	mat1_shininess		= new GLfloat[1]; //<------------------------Reserve memory
	mat1_shininess[0]	= 100.0f; //<--------------------------------shininess for material 1

	spot0_position		= new GLfloat[4]; //<------------------------Reserve memory
	spot0_position[0]	=  0.0f; //<---------------------------------L0x
	spot0_position[1]	=  2.0f; //<---------------------------------L0y
	spot0_position[2]	=  0.0f; //<---------------------------------L0z
	spot0_position[3]	=  1.0f; //<---------------------------------L0w

	spot0_specular		= new GLfloat[4]; //<------------------------Reserve memory
	spot0_specular[0]	= 1.0f; //<----------------------------------L0Sr
	spot0_specular[1]	= 1.0f; //<----------------------------------L0Sg
	spot0_specular[2]	= 1.0f; //<----------------------------------L0Sb
	spot0_specular[3]	= 1.0f; //<----------------------------------L0Sa

	spot0_diffuse		= new GLfloat[4]; //<------------------------Reserve memory
	spot0_diffuse[0]	= 1.0f; //<----------------------------------L0Dr
	spot0_diffuse[1]	= 0.9f; //<----------------------------------L0Dg
	spot0_diffuse[2]	= 0.9f; //<----------------------------------L0Db
	spot0_diffuse[3]	= 1.0f; //<----------------------------------L0Da

	spot0_ambient		= new GLfloat[4]; //<------------------------Reserve memory
	spot0_ambient[0]	= 0.1f; //<----------------------------------L0Ar
	spot0_ambient[1]	= 0.1f; //<----------------------------------L0Ag
	spot0_ambient[2]	= 0.1f; //<----------------------------------L0Ab
	spot0_ambient[3]	= 1.0f; //<----------------------------------L0Aa

	spot0_direction		= new GLfloat[3]; //<------------------------Reserve memory
	spot0_direction[0]	=  0.0f; //<---------------------------------L0Vx
	spot0_direction[1]	= -1.0f; //<---------------------------------L0Vy
	spot0_direction[2]	=  0.0f; //<---------------------------------L0Vz

	spot0_att_constant	= 0.2f; //<----------------------------------Constant attenuation
	spot0_att_linear	= 0.2f; //<----------------------------------Linear attenuation
	spot0_att_quadratic = 0.2f; //<----------------------------------Quadratic attenuation

	spot0_exponent		= 2.0f; //<----------------------------------Spot power
	spot0_cutoff		= 45.0f; //<---------------------------------Cutting angle

// Configure Light 0:
	glLightfv( GL_LIGHT0, GL_POSITION,				spot0_position		);
	glLightfv( GL_LIGHT0, GL_AMBIENT,				spot0_ambient		);
	glLightfv( GL_LIGHT0, GL_DIFFUSE,				spot0_diffuse		);
	glLightfv( GL_LIGHT0, GL_SPECULAR,				spot0_specular		);
	glLightf ( GL_LIGHT0, GL_CONSTANT_ATTENUATION,	spot0_att_constant	);
	glLightf ( GL_LIGHT0, GL_LINEAR_ATTENUATION,	spot0_att_linear	);
	glLightf ( GL_LIGHT0, GL_QUADRATIC_ATTENUATION, spot0_att_quadratic	);
	glLightf ( GL_LIGHT0, GL_SPOT_CUTOFF,			spot0_cutoff		);
	glLightfv( GL_LIGHT0, GL_SPOT_DIRECTION,		spot0_direction		);
	glLightf ( GL_LIGHT0, GL_SPOT_EXPONENT,			spot0_exponent		);

// Enable Light 0:
	glEnable( GL_LIGHT0 );
// Enable lighting:
	glEnable( GL_LIGHTING );
// Enable depth test (distinguish between near and far faces):
	glEnable( GL_DEPTH_TEST );
// Assign initial rotation angle:
	rotation = 0.0f;
}
//
//----------------------------------------------------------------------------------------------
//
void display( void )
{
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	glPushMatrix();
	{
		glRotatef( rotation, 0.0f, 1.0f, 1.0f );
		
		glMaterialfv( GL_FRONT,  GL_AMBIENT,   mat0_ambient		);
		glMaterialfv( GL_FRONT,	 GL_DIFFUSE,   mat0_diffuse		);
		glMaterialfv( GL_FRONT,  GL_SPECULAR,  mat0_specular	);
		glMaterialfv( GL_FRONT,  GL_SHININESS, mat0_shininess	);
		glPushMatrix();
		{
			glTranslatef( 1.0f, 0.0f, 0.0f );
			glutSolidSphere( 0.5, 40, 40 );
		}
		glPopMatrix();
		
		glMaterialfv( GL_FRONT,  GL_AMBIENT,   mat1_ambient		);
		glMaterialfv( GL_FRONT,	 GL_DIFFUSE,   mat1_diffuse		);
		glMaterialfv( GL_FRONT,  GL_SPECULAR,  mat1_specular	);
		glMaterialfv( GL_FRONT,  GL_SHININESS, mat1_shininess	);
		glPushMatrix();
		{
			glTranslatef( -1.0f, 0.0f, 0.0f );
			glutSolidSphere( 0.5, 40, 40 );
		}
		glPopMatrix();
	}
	glPopMatrix();
	glutSwapBuffers();
}
//
//----------------------------------------------------------------------------------------------
//
void idle( void )
{
	rotation += 0.02f;
	if( rotation > 360.0f )
	{
		rotation = 0.0f;
	}
	glutPostRedisplay();
}
//
//----------------------------------------------------------------------------------------------
//
void reshape( int w, int h )
{
	glViewport( 0, 0, (GLsizei) w, (GLsizei) h );
	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();
	if( w <= h )
	{
		glOrtho(- 1.5, 
				  1.5, 
				- 1.5 * (GLfloat)h / (GLfloat)w,
				  1.5 * (GLfloat)h / (GLfloat)w,
				-10.0,
				 10.0							);
	}
	else
	{
	    glOrtho(- 1.5 * (GLfloat)w / (GLfloat)h,
				  1.5 * (GLfloat)w / (GLfloat)h,
			    - 1.5,
				  1.5,
			    -10.0,
			     10.0							);
	}
	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();
}
//
//----------------------------------------------------------------------------------------------
//
int main( int argc, char** argv )
{
	glutInit( &argc, argv );
	glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH );
	glutInitWindowSize( 500, 500 );
	glutInitWindowPosition( 100, 100 );
	glutCreateWindow( argv[0] );
	init();
	glutDisplayFunc( display ); 
	glutReshapeFunc( reshape );
	glutIdleFunc( idle );
	glutMainLoop();
	return 0;
}
//
//----------------------------------------------------------------------------------------------