#pragma once
#ifdef __APPLE__
	#include <OpenGL/gl.h>
	#include <OpenGL/glu.h>
	#include <GLUT/glut.h>
#else
	#include "freeglut.h"
#endif
//----------------------------------------------------------------------------------------------
//
#ifndef __AXES
#define __AXES

class Axes
{
public:
			Axes	( float scale	);
			~Axes	( void			);

	void	draw	( void			);
private:
	GLuint	axesList;
};

#endif __AXES
//
//----------------------------------------------------------------------------------------------
