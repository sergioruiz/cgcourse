#pragma once
#ifdef __APPLE__
	#include <OpenGL/gl.h>
	#include <OpenGL/glu.h>
	#include <GLUT/glut.h>
#else
	#include "freeglut.h"
#endif
//----------------------------------------------------------------------------------------------
//
#ifndef __CUBE
#define __CUBE

class Cube
{
public:
			Cube	( GLfloat side	);
			~Cube	( void			);

	void	display	( void			);

private:
	GLfloat hside;
	GLuint	listID;
};

#endif __CUBE
//
//----------------------------------------------------------------------------------------------
