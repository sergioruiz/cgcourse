#include "cCube.h"
//
//----------------------------------------------------------------------------------------------
//
/*
	Constructor de Cubo.
	Recibe la longitud de un lado del cubo como par�metro.
*/
Cube::Cube( GLfloat side )
{
	hside  = side / 2.0f;
	listID = glGenLists( 1 ); // genera 1 ID para lista de despliegue.

	glNewList( listID, GL_COMPILE );
	glBegin( GL_QUADS ); // Cara frontal
		glNormal3f(  0.0f,   0.0f,  1.0f  );
		glVertex3f( -hside, -hside, hside );
		glNormal3f(  0.0f,   0.0f,  1.0f  );
		glVertex3f(  hside, -hside, hside );
		glNormal3f(  0.0f,   0.0f,  1.0f  );
		glVertex3f(  hside,  hside, hside );
		glNormal3f(  0.0f,   0.0f,  1.0f  );
		glVertex3f( -hside,  hside, hside );
	glEnd();
	glBegin( GL_QUADS ); // Cara derecha
		glNormal3f(  1.0f,   0.0f,   0.0f  );
		glVertex3f(  hside, -hside,  hside );
		glNormal3f(  1.0f,   0.0f,   0.0f  );
		glVertex3f(  hside, -hside, -hside );
		glNormal3f(  1.0f,   0.0f,   0.0f  );
		glVertex3f(  hside,  hside, -hside );
		glNormal3f(  1.0f,   0.0f,   0.0f  );
		glVertex3f(  hside,  hside,  hside );
	glEnd();
	glBegin( GL_QUADS ); // Cara trasera
		glNormal3f(  0.0f,   0.0f,  -1.0f  );
		glVertex3f(  hside, -hside, -hside );
		glNormal3f(  0.0f,   0.0f,  -1.0f  );
		glVertex3f( -hside, -hside, -hside );
		glNormal3f(  0.0f,   0.0f,  -1.0f  );
		glVertex3f( -hside,  hside, -hside );
		glNormal3f(  0.0f,   0.0f,  -1.0f  );
		glVertex3f(  hside,  hside, -hside );
	glEnd();
	glBegin( GL_QUADS ); // Cara izquierda
		glNormal3f( -1.0f,   0.0f,   0.0f  );
		glVertex3f( -hside, -hside, -hside );
		glNormal3f( -1.0f,   0.0f,   0.0f  );
		glVertex3f( -hside, -hside,  hside );
		glNormal3f( -1.0f,   0.0f,   0.0f  );
		glVertex3f( -hside,  hside,  hside );
		glNormal3f( -1.0f,   0.0f,   0.0f  );
		glVertex3f( -hside,  hside, -hside );
	glEnd();
	glBegin( GL_QUADS ); // Cara superior
		glNormal3f(  0.0f,   1.0f,   0.0f  );
		glVertex3f( -hside,  hside,  hside );
		glNormal3f(  0.0f,   1.0f,   0.0f  );
		glVertex3f(  hside,  hside,  hside );
		glNormal3f(  0.0f,   1.0f,   0.0f  );
		glVertex3f(  hside,  hside, -hside );
		glNormal3f(  0.0f,   1.0f,   0.0f  );
		glVertex3f( -hside,  hside, -hside );
	glEnd();
	glBegin( GL_QUADS ); // Cara inferior
		glNormal3f(  0.0f,  -1.0f,   0.0f  );
		glVertex3f( -hside, -hside,  hside );
		glNormal3f(  0.0f,  -1.0f,   0.0f  );
		glVertex3f(  hside, -hside,  hside );
		glNormal3f(  0.0f,  -1.0f,   0.0f  );
		glVertex3f(  hside, -hside, -hside );
		glNormal3f(  0.0f,  -1.0f,   0.0f  );
		glVertex3f( -hside, -hside, -hside );
	glEnd();	
	glEndList();
}
//
//----------------------------------------------------------------------------------------------
//
/*
	Destructor de Cubo.
	Libera la memoria utilizada por esta Clase.
*/Cube::~Cube( void )
{
	glDeleteLists( listID, 1 ); //<----------------------------------Libera la memoria asociada a la lista de despliegue.
}
//
//----------------------------------------------------------------------------------------------
//
/*
	Despliegue de Cubo.
	Llamada a la ejecuci�n de listID.
*/
void Cube::display( void )
{
	glCallList( listID ); //<----------------------------------------Ejecuta la lista de despliegue compilada.
}
//
//----------------------------------------------------------------------------------------------
//