#include "cAxes.h"
//----------------------------------------------------------------------------------------------
//
Axes::Axes( float scale )
{
	axesList = glGenLists( 1 );
	glNewList( axesList, GL_COMPILE );
	{
		int x = 0, y = 0, z = 0;
		// Eje X:
		glColor3f( 1.0f, 0.0f, 0.0f );
		glBegin( GL_LINES );
		{
			glVertex3f( 0.0f, 0.0f, 0.0f );
			glVertex3f( scale, 0.0f, 0.0f );
		}
		glEnd();
		// Marcadores cada 10 unidades:
		while( x <= scale )
		{
			glPushMatrix();
			{
				glTranslatef( (float)x, 0.0f, 0.0f );
				glutSolidSphere( 0.5f, 10, 10 );
				x += 10;
			}
			glPopMatrix();
		}
		// Eje Y:
		glColor3f( 0.0f, 1.0f, 0.0f );
		glBegin( GL_LINES );
		{
			glVertex3f( 0.0f, 0.0f, 0.0f );
			glVertex3f( 0.0f, scale, 0.0f );
		}
		glEnd();
		// Marcadores cada 10 unidades:
		while( y <= scale )
		{
			glPushMatrix();
			{
				glTranslatef( 0.0f, (float)y, 0.0f );
				glutSolidSphere( 0.5f, 10, 10 );
				y += 10;
			}
			glPopMatrix();
		}
		// Eje Z:
		glColor3f( 0.0f, 0.0f, 1.0f );
		glBegin( GL_LINES );
		{
			glVertex3f( 0.0f, 0.0f, 0.0f );
			glVertex3f( 0.0f, 0.0f, scale );
		}
		glEnd();
		// Marcadores cada 10 unidades:
		while( z <= scale )
		{
			glPushMatrix();
			{
				glTranslatef( 0.0f, 0.0f, (float)z );
				glutSolidSphere( 0.5f, 10, 10 );
				z += 10;
			}
			glPopMatrix();
		}
		// Ejes negativos:
		glColor3f( 0.5f, 0.5f, 0.5f );
		glBegin( GL_LINES );
		{
			glVertex3f(  0.0f,  0.0f, 0.0f );
			glVertex3f( -scale, 0.0f, 0.0f );
		}
		glEnd();
		glBegin( GL_LINES );
		{
			glVertex3f( 0.0f,  0.0f,  0.0f );
			glVertex3f( 0.0f, -scale, 0.0f );
		}
		glEnd();
		glBegin( GL_LINES );
		{
			glVertex3f( 0.0f, 0.0f,  0.0f  );
			glVertex3f( 0.0f, 0.0f, -scale );
		}
		glEnd();
	}
	glEndList();
}
//
//----------------------------------------------------------------------------------------------
//
Axes::~Axes( void )
{
	glDeleteLists( axesList, 1 ); //<--------------------------------Liberar memoria asociada a la lista de despliegue.
}
//
//----------------------------------------------------------------------------------------------
//
void Axes::draw( void )
{
	glPushAttrib( GL_LIGHTING_BIT ); //<-----------------------------'Recordar' si la luz estaba habilitada.
	{
		glDisable( GL_LIGHTING ); //<--------------------------------Deshabilitar luz para poder dibujar con glColor.
		glCallList( axesList ); //<----------------------------------Ejecutar la lista compilada.
	}
	glPopAttrib(); //<-----------------------------------------------'Recuperar' el estado de la luz.
}
//
//----------------------------------------------------------------------------------------------
