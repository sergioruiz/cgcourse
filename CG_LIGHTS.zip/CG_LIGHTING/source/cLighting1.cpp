/*
	TC3022. Computer Graphics

	Basic lighting example 1.
	Displays a shaded sphere.
*/

#ifdef __APPLE__
	#include <OpenGL/gl.h>
	#include <OpenGL/glu.h>
	#include <GLUT/glut.h>
#else
	#include "freeglut.h"
#endif

GLfloat		rotation;
GLfloat*    mat0_ambient;
// ksr, ksg, ksb:
GLfloat*	mat0_specular; //<---------------------------------------Material 0 - specular
// kdr, kdg, kdb:
GLfloat*	mat0_diffuse; //<----------------------------------------Material 0 - diffuse
// alpha:
GLfloat*	mat0_shininess; //<--------------------------------------Material 0 - specular power
// Ir, Ig, Ib:
GLfloat*	light0_position; //<-------------------------------------Light 0    - location
//
//----------------------------------------------------------------------------------------------
//
void init( void )
{
	glClearColor ( 0.0f, 0.0f, 0.0f, 0.0f ); //<---------------------Clear color
	glShadeModel ( GL_SMOOTH ); //<----------------------------------Smooth shading

//->MATERIAL 0 BEGINS
	mat0_ambient		= new GLfloat[4]; //<------------------------Reserve memory
	mat0_ambient[0]	= 0.01f; //<----------------------------------S0r
	mat0_ambient[1]	= 0.01f; //<----------------------------------S0g
	mat0_ambient[2]	= 0.01f; //<----------------------------------S0b
	mat0_ambient[3]	= 1.0f; //<----------------------------------S0a



	mat0_specular		= new GLfloat[4]; //<------------------------Reserve memory
	mat0_specular[0]	= 1.0f; //<----------------------------------S0r
	mat0_specular[1]	= 1.0f; //<----------------------------------S0g
	mat0_specular[2]	= 1.0f; //<----------------------------------S0b
	mat0_specular[3]	= 1.0f; //<----------------------------------S0a

	mat0_diffuse		= new GLfloat[4]; //<------------------------Reserve memory
	mat0_diffuse[0]		= 1.0f; //<----------------------------------D0r
	mat0_diffuse[1]		= 0.0f; //<----------------------------------D0g
	mat0_diffuse[2]		= 0.0f; //<----------------------------------D0b
	mat0_diffuse[3]		= 1.0f; //<----------------------------------D0a

	mat0_shininess		= new GLfloat[1]; //<------------------------Reserve memory
	mat0_shininess[0]	= 60.0f; //<---------------------------------Material 0 specular power
//<-MATERIAL 0 ENDS

//->LIGHT 0 BEGINS
	light0_position		= new GLfloat[4]; //<------------------------Reserve memory
	light0_position[0]	= 1.0f; //<----------------------------------L0x
	light0_position[1]	= 1.0f; //<----------------------------------L0y
	light0_position[2]	= 1.0f; //<----------------------------------L0z
	light0_position[3]	= 0.0f; //<----------------------------------L0w

/*
	Important: light position is L0(lx,ly,lz,lw).
		-If lw = 0, configures a directional light, and parameters lx, ly y lz define its direction.
		-If lw = 1, configures a point light, and parameters lx, ly y lz define its location.
*/
//<-LIGHT 0 ENDS

// Locate LIGHT 0:
	glLightfv( GL_LIGHT0, GL_POSITION,  light0_position );
// Enable lighting:
	glEnable( GL_LIGHTING );
// Enable LIGHT 0:
	glEnable( GL_LIGHT0 );
// Enable depth test (distinguish between near and far faces):
	glEnable( GL_DEPTH_TEST );
// Assign initial rotation angle:
	rotation = 0.0f;
}
//
//----------------------------------------------------------------------------------------------
//
/*
	Callback triggered when display is required.
*/
void display( void )
{
// Clear depth and color buffers:
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
// State machine: set active material:
	//glMaterialfv( GL_FRONT, GL_AMBIENT, mat0_ambient);
	glMaterialfv( GL_FRONT,	 GL_DIFFUSE,   mat0_diffuse		);
	glMaterialfv( GL_FRONT,  GL_SPECULAR,  mat0_specular	);
	glMaterialfv( GL_FRONT,  GL_SHININESS, mat0_shininess	);
// Draw polygons:
	glPushMatrix();
	{
		glRotatef( rotation, 0.0f, 1.0f, 0.0f );
		glutSolidSphere( 1.0, 20, 20 );
	}
	glPopMatrix();
// Exchange visible and hidden buffers:
	glutSwapBuffers();
}
//
//----------------------------------------------------------------------------------------------
//
/*
	Callback triggered when drawing routines are done.
*/
void idle( void )
{
	rotation += 0.01f; //<-------------------------------------------Increase rotation.
	if( rotation > 360.0f ) //<--------------------------------------Limit rotation.
	{
		rotation = 0.0f;
	}
	glutPostRedisplay(); //<-----------------------------------------Draw again.
}
//
//----------------------------------------------------------------------------------------------
//
/*
	Callback triggered when window dimensions change.
*/
void reshape( int w, int h )
{
// Update the viewport:
	glViewport( 0, 0, (GLsizei) w, (GLsizei) h );
// Go to projection mode (2D):
	glMatrixMode( GL_PROJECTION );
// Load identity matrix in the active matrix (GL_PROJECTION):
	glLoadIdentity();
// Adjust the frustum:
	if( w <= h )
	{
		glOrtho(- 1.5, 
				  1.5, 
				- 1.5 * (GLfloat)h / (GLfloat)w,
				  1.5 * (GLfloat)h / (GLfloat)w,
				-10.0,
				 10.0							);
	}
	else
	{
	    glOrtho(- 1.5 * (GLfloat)w / (GLfloat)h,
				  1.5 * (GLfloat)w / (GLfloat)h,
			    - 1.5,
				  1.5,
			    -10.0,
			     10.0							);
	}
// Go to model-view mode (3D):
	glMatrixMode( GL_MODELVIEW );
// Load identity matrix in the active matrix (GL_MODELVIEW):
	glLoadIdentity();
}
//
//----------------------------------------------------------------------------------------------
//
/*
	Main function.
	Configure GLUT and execute GLUT MAIN LOOP.
*/
int main( int argc, char** argv )
{
// Initialize GLUT:
	glutInit( &argc, argv );
// Initialize the display mode using 2 buffers (visible and hidden), 
// 3 color channels and the depth buffer:
	glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH );
// Initialize window and size:
	glutInitWindowSize( 500, 500 );
// Set window position:
	glutInitWindowPosition( 100, 100 );
// Display the window and set its title to this program's name.
	glutCreateWindow( argv[0] );
// Call 'init':
	init();
// Register GLUT callbacks:
	glutDisplayFunc( display ); 
	glutReshapeFunc( reshape );
	glutIdleFunc( idle );
// Start rendering:
	glutMainLoop();
// ANSI C requires an integer. 0: OK, other than 0: error number.
	return 0;
}
//
//----------------------------------------------------------------------------------------------