/*
	TC3022. Computer Graphics

	Basic lighting example 2.
	Displays a shaded sphere and a torus.
		-Source 1: point.
		-Source 2: point.
*/

#ifdef __APPLE__
	#include <OpenGL/gl.h>
	#include <OpenGL/glu.h>
	#include <GLUT/glut.h>
#else
	#include "freeglut.h"
#endif

GLfloat		rotation;
GLfloat*	mat0_specular; //<---------------------------------------Material 0 - specular
GLfloat*	mat0_diffuse; //<----------------------------------------Material 0 - diffuse
GLfloat*	mat0_ambient; //<----------------------------------------Material 0 - ambient
GLfloat*	mat0_shininess; //<--------------------------------------Material 0 - shininess

GLfloat*	mat1_specular; //<---------------------------------------Material 1 - specular
GLfloat*	mat1_diffuse; //<----------------------------------------Material 1 - diffuse
GLfloat*	mat1_ambient; //<----------------------------------------Material 1 - ambient
GLfloat*	mat1_shininess; //<--------------------------------------Material 1 - shininess

GLfloat*	light0_position; //<-------------------------------------Light 0 - location
GLfloat*	light0_diffuse; //<--------------------------------------Light 0 - diffuse
GLfloat*	light0_specular; //<-------------------------------------Light 0 - specular
GLfloat*	light0_ambient; //<--------------------------------------Light 0 - ambient

GLfloat*	light1_position; //<-------------------------------------Light 1 - location
GLfloat*	light1_diffuse; //<--------------------------------------Light 1 - diffuse
GLfloat*	light1_specular; //<-------------------------------------Light 1 - specular
GLfloat*	light1_ambient; //<--------------------------------------Light 1 - ambient
//
//----------------------------------------------------------------------------------------------
//
void init( void )
{
	glClearColor ( 0.0f, 0.0f, 0.0f, 0.0f ); //<---------------------Clear color
	glShadeModel ( GL_SMOOTH ); //<----------------------------------Set smooth shading

//->material 0 begins
	mat0_specular		= new GLfloat[4]; //<------------------------Reserve memory
	mat0_specular[0]	= 1.0f; //<----------------------------------S0r
	mat0_specular[1]	= 1.0f; //<----------------------------------S0g
	mat0_specular[2]	= 1.0f; //<----------------------------------S0b
	mat0_specular[3]	= 1.0f; //<----------------------------------S0a

	mat0_diffuse		= new GLfloat[4]; //<------------------------Reserve memory
	mat0_diffuse[0]		= 1.0f; //<----------------------------------D0r
	mat0_diffuse[1]		= 0.0f; //<----------------------------------D0g
	mat0_diffuse[2]		= 0.0f; //<----------------------------------D0b
	mat0_diffuse[3]		= 1.0f; //<----------------------------------D0a

	mat0_ambient		= new GLfloat[4]; //<------------------------Reserve memory
	mat0_ambient[0]		= 0.1f; //<----------------------------------A0r
	mat0_ambient[1]		= 0.1f; //<----------------------------------A0g
	mat0_ambient[2]		= 0.1f; //<----------------------------------A0b
	mat0_ambient[3]		= 1.0f; //<----------------------------------A0a

	mat0_shininess		= new GLfloat[1]; //<------------------------Reserve memory
	mat0_shininess[0]	= 60.0f; //<---------------------------------Material 0 shininess
//<-material 0 ends

//->material 1 begins
	mat1_specular		= new GLfloat[4]; //<------------------------Reserve memory
	mat1_specular[0]	= 1.0f; //<----------------------------------S1r
	mat1_specular[1]	= 1.0f; //<----------------------------------S1g
	mat1_specular[2]	= 1.0f; //<----------------------------------S1b
	mat1_specular[3]	= 1.0f; //<----------------------------------S1a

	mat1_diffuse		= new GLfloat[4]; //<------------------------Reserve memory
	mat1_diffuse[0]		= 0.0f; //<----------------------------------D1r
	mat1_diffuse[1]		= 0.0f; //<----------------------------------D1g
	mat1_diffuse[2]		= 1.0f; //<----------------------------------D1b
	mat1_diffuse[3]		= 1.0f; //<----------------------------------D1a

	mat1_ambient		= new GLfloat[4]; //<------------------------Reserve memory
	mat1_ambient[0]		= 0.1f; //<----------------------------------A1r
	mat1_ambient[1]		= 0.1f; //<----------------------------------A1g
	mat1_ambient[2]		= 0.1f; //<----------------------------------A1b
	mat1_ambient[3]		= 1.0f; //<----------------------------------A1a

	mat1_shininess		= new GLfloat[1]; //<------------------------Reserve memory
	mat1_shininess[0]	= 60.0f; //<---------------------------------material 1 shininess
//<-material 1 ends

//->LIGHT 0 begins
	light0_position		= new GLfloat[4]; //<------------------------Reserve memory
	light0_position[0]	= 5.0f; //<----------------------------------L0x
	light0_position[1]	= 1.0f; //<----------------------------------L0y
	light0_position[2]	= 1.0f; //<----------------------------------L0z
	light0_position[3]	= 0.0f; //<----------------------------------L0w

	light0_specular		= new GLfloat[4]; //<------------------------Reserve memory
	light0_specular[0]	= 1.0f; //<----------------------------------L0Sr
	light0_specular[1]	= 1.0f; //<----------------------------------L0Sg
	light0_specular[2]	= 1.0f; //<----------------------------------L0Sb
	light0_specular[3]	= 1.0f; //<----------------------------------L0Sa

	light0_diffuse		= new GLfloat[4]; //<------------------------Reserve memory
	light0_diffuse[0]	= 1.0f; //<----------------------------------L0Dr
	light0_diffuse[1]	= 0.9f; //<----------------------------------L0Dg
	light0_diffuse[2]	= 0.9f; //<----------------------------------L0Db
	light0_diffuse[3]	= 1.0f; //<----------------------------------L0Da

	light0_ambient		= new GLfloat[4]; //<------------------------Reserve memory
	light0_ambient[0]	= 0.1f; //<----------------------------------L0Ar
	light0_ambient[1]	= 0.1f; //<----------------------------------L0Ag
	light0_ambient[2]	= 0.1f; //<----------------------------------L0Ab
	light0_ambient[3]	= 1.0f; //<----------------------------------L0Aa
//<-LIGHT 0 ends

//->LIGHT 1 begins
	light1_position		= new GLfloat[4]; //<------------------------Reserve memory
	light1_position[0]	= -5.0f; //<---------------------------------L1x
	light1_position[1]	=  1.0f; //<---------------------------------L1y
	light1_position[2]	=  1.0f; //<---------------------------------L1z
	light1_position[3]	=  0.0f; //<---------------------------------L1w

	light1_specular		= new GLfloat[4]; //<------------------------Reserve memory
	light1_specular[0]	= 1.0f; //<----------------------------------L1Sr
	light1_specular[1]	= 1.0f; //<----------------------------------L1Sg
	light1_specular[2]	= 1.0f; //<----------------------------------L1Sb
	light1_specular[3]	= 1.0f; //<----------------------------------L1Sa

	light1_diffuse		= new GLfloat[4]; //<------------------------Reserve memory
	light1_diffuse[0]	= 0.9f; //<----------------------------------L1Dr
	light1_diffuse[1]	= 0.9f; //<----------------------------------L1Dg
	light1_diffuse[2]	= 1.0f; //<----------------------------------L1Db
	light1_diffuse[3]	= 1.0f; //<----------------------------------L1Da

	light1_ambient		= new GLfloat[4]; //<------------------------Reserve memory
	light1_ambient[0]	= 0.1f; //<----------------------------------L1Ar
	light1_ambient[1]	= 0.1f; //<----------------------------------L1Ag
	light1_ambient[2]	= 0.1f; //<----------------------------------L1Ab
	light1_ambient[3]	= 1.0f; //<----------------------------------L1Aa
//<-LIGHT 1 ends

// Configure LIGHT 0:
	glLightfv( GL_LIGHT0, GL_POSITION,  light0_position );
	glLightfv( GL_LIGHT0, GL_AMBIENT,   light0_ambient);
	glLightfv( GL_LIGHT0, GL_DIFFUSE,   light0_diffuse);
	glLightfv( GL_LIGHT0, GL_SPECULAR,  light0_specular);
// Configure LIGHT 1:
	glLightfv( GL_LIGHT1, GL_POSITION,  light1_position );
	glLightfv( GL_LIGHT1, GL_AMBIENT,   light1_ambient);
	glLightfv( GL_LIGHT1, GL_DIFFUSE,   light1_diffuse);
	glLightfv( GL_LIGHT1, GL_SPECULAR,  light1_specular);
// Enable LIGHT 0:
	glEnable( GL_LIGHT0 );
// Enable LIGHT 1:
	glEnable( GL_LIGHT1 );
// Enable lighting:
	glEnable( GL_LIGHTING );
// Enable depth test (distinguish between near and far faces):
	glEnable( GL_DEPTH_TEST );
// Assign initial rotation angle:
	rotation = 0.0f;
}
//
//----------------------------------------------------------------------------------------------
//
/*
	Callback triggered when display is required.
*/
void display( void )
{
// Clear depth and color buffers:
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
// Draw polygons:
	glPushMatrix();
	{
		glRotatef( rotation, 0.0f, 1.0f, 0.0f );
		glTranslatef( -0.6f, 0.0f, 0.0f );
// State machine: set active material:
		glMaterialfv( GL_FRONT,  GL_AMBIENT,   mat0_ambient		);
		glMaterialfv( GL_FRONT,	 GL_DIFFUSE,   mat0_diffuse		);
		glMaterialfv( GL_FRONT,  GL_SPECULAR,  mat0_specular	);
		glMaterialfv( GL_FRONT,  GL_SHININESS, mat0_shininess	);
// Draw:
		glutSolidSphere( 0.5, 40, 40 );
		
		glTranslatef( 1.2f, 0.0f, 0.0f );
		
// State machine: set active material:
		glMaterialfv( GL_FRONT,  GL_AMBIENT,   mat1_ambient		);
		glMaterialfv( GL_FRONT,	 GL_DIFFUSE,   mat1_diffuse		);
		glMaterialfv( GL_FRONT,  GL_SPECULAR,  mat1_specular	);
		glMaterialfv( GL_FRONT,  GL_SHININESS, mat1_shininess	);
// Draw:
		glutSolidTorus( 0.2, 0.4, 30, 30 );
	}
	glPopMatrix();
// Exchange visible and hidden buffers:
	glutSwapBuffers();
}
//
//----------------------------------------------------------------------------------------------
//
/*
	Callback triggered when drawing routines are done.
*/
void idle( void )
{
	rotation += 0.01f; //<-------------------------------------------Increase rotation.
	if( rotation > 360.0f ) //<--------------------------------------Limit rotation.
	{
		rotation = 0.0f;
	}
	glutPostRedisplay(); //<-----------------------------------------Draw again.
}
//
//----------------------------------------------------------------------------------------------
//
/*
	Callback triggered when window dimensions change.
*/
void reshape( int w, int h )
{
// Update the viewport:
	glViewport( 0, 0, (GLsizei) w, (GLsizei) h );
// Go to projection mode (2D):
	glMatrixMode( GL_PROJECTION );
// Load identity matrix in the active matrix (GL_PROJECTION):
	glLoadIdentity();
// Adjust the frustum:
	if( w <= h )
	{
		glOrtho(- 1.5, 
				  1.5, 
				- 1.5 * (GLfloat)h / (GLfloat)w,
				  1.5 * (GLfloat)h / (GLfloat)w,
				-10.0,
				 10.0							);
	}
	else
	{
	    glOrtho(- 1.5 * (GLfloat)w / (GLfloat)h,
				  1.5 * (GLfloat)w / (GLfloat)h,
			    - 1.5,
				  1.5,
			    -10.0,
			     10.0							);
	}
// Go to model-view mode (3D):
	glMatrixMode( GL_MODELVIEW );
// Load identity matrix in the active matrix (GL_MODELVIEW):
	glLoadIdentity();
}
//
//----------------------------------------------------------------------------------------------
//
/*
	Main function.
	Configure GLUT and execute GLUT MAIN LOOP.
*/
int main( int argc, char** argv )
{
// Initialize GLUT:
	glutInit( &argc, argv );
// Initialize the display mode using 2 buffers (visible and hidden), 
// 3 color channels and the depth buffer:
	glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH );
// Initialize window and size:
	glutInitWindowSize( 500, 500 );
// Set window position:
	glutInitWindowPosition( 100, 100 );
// Display the window and set its title to this program's name.
	glutCreateWindow( argv[0] );
// Call 'init':
	init();
// Register GLUT callbacks:
	glutDisplayFunc( display ); 
	glutReshapeFunc( reshape );
	glutIdleFunc( idle );
// Start rendering:
	glutMainLoop();
// ANSI C requires an integer. 0: OK, other than 0: error number.
	return 0;
}
//
//----------------------------------------------------------------------------------------------
