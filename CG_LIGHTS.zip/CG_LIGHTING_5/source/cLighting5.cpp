/*
	TC3022. Computer Graphics

	Basic lighting example 5.
	Displays a shaded sphere.
		-Emissive material.
*/

#ifdef __APPLE__
	#include <OpenGL/gl.h>
	#include <OpenGL/glu.h>
	#include <GLUT/glut.h>
#else
	#include "freeglut.h"
#endif

GLfloat		rotation;
GLfloat*	mat0_specular; //<---------------------------------------Material 0 - especular
GLfloat*	mat0_diffuse; //<----------------------------------------Material 0 - difuso
GLfloat*	mat0_shininess; //<--------------------------------------Material 0 - brillo
GLfloat*	mat0_emission; //<---------------------------------------Material 0 - emisivo
GLfloat*	light0_position; //<-------------------------------------Luz 0 - posici�n
//
//----------------------------------------------------------------------------------------------
//
/*
	Funci�n para inicializar variables del programa.
*/
void init( void )
{
	glClearColor ( 0.0f, 0.0f, 0.0f, 0.0f ); //<---------------------'Borrar' pantalla
	glShadeModel ( GL_SMOOTH ); //<----------------------------------Indicar sombreado suave

//->Inicia definir material 0
	mat0_specular		= new GLfloat[4]; //<------------------------Asignar memoria
	mat0_specular[0]	= 1.0f; //<----------------------------------S0r
	mat0_specular[1]	= 1.0f; //<----------------------------------S0g
	mat0_specular[2]	= 1.0f; //<----------------------------------S0b
	mat0_specular[3]	= 1.0f; //<----------------------------------S0a

	mat0_diffuse		= new GLfloat[4]; //<------------------------Asignar memoria
	mat0_diffuse[0]		= 1.0f; //<----------------------------------D0r
	mat0_diffuse[1]		= 1.0f; //<----------------------------------D0g
	mat0_diffuse[2]		= 0.0f; //<----------------------------------D0b
	mat0_diffuse[3]		= 1.0f; //<----------------------------------D0a

	mat0_emission		= new GLfloat[4]; //<------------------------Asignar memoria
	mat0_emission[0]	= 1.0f; //<----------------------------------E0r
	mat0_emission[1]	= 1.0f; //<----------------------------------E0g
	mat0_emission[2]	= 0.0f; //<----------------------------------E0b
	mat0_emission[3]	= 1.0f; //<----------------------------------E0a

	mat0_shininess		= new GLfloat[1]; //<------------------------Asignar memoria
	mat0_shininess[0]	= 60.0f; //<---------------------------------Brillo del material 0
//<-Termina definir material 0

//->Inicia definir luz 0
	light0_position		= new GLfloat[4]; //<------------------------Asignar memoria
	light0_position[0]	= 1.0f; //<----------------------------------L0x
	light0_position[1]	= 1.0f; //<----------------------------------L0y
	light0_position[2]	= 1.0f; //<----------------------------------L0z
	light0_position[3]	= 0.0f; //<----------------------------------L0w
//<-Termina definir luz 0

// Posicionar LUZ 0:
	glLightfv( GL_LIGHT0, GL_POSITION,  light0_position );
// Habilitar iluminaci�n:
	glEnable( GL_LIGHTING );
// Habilitar LUZ 0:
	glEnable( GL_LIGHT0 );
// Habilitar prueba de profundidad (distinguir entre caras cercanas y lejanas):
	glEnable( GL_DEPTH_TEST );
// Asignar �ngulo de rotaci�n inicial:
	rotation = 0.0f;
}
//
//----------------------------------------------------------------------------------------------
//
/*
	Callback a llamar cuando la ventana cambia de dimensiones.
*/
void display( void )
{
// Limpiar los buffers de color y de profundidad:
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
// Indicar propiedades del material con el que vamos a dibujar:
	glMaterialfv( GL_FRONT,	 GL_DIFFUSE,   mat0_diffuse		);
	glMaterialfv( GL_FRONT,  GL_SPECULAR,  mat0_specular	);
	glMaterialfv( GL_FRONT,  GL_SHININESS, mat0_shininess	);
	glMaterialfv( GL_FRONT,  GL_EMISSION,  mat0_emission	);
// Dibujar los pol�gonos:
	glPushMatrix();
		glRotatef( rotation, 0.0f, 1.0f, 0.0f );
		glutSolidSphere( 1.0, 40, 40 );
	glPopMatrix();
// Intercambiar el buffer visible por el oculto:
	glutSwapBuffers();
}
//
//----------------------------------------------------------------------------------------------
//
/*
	Callback a llamar cuando se ha terminado de dibujar.
*/
void idle( void )
{
	rotation += 0.02f;
	if( rotation > 360.0f )
	{
		rotation = 0.0f;
	}
	glutPostRedisplay();
}
//
//----------------------------------------------------------------------------------------------
//
/*
	Callback a llamar cuando la ventana cambia de dimensiones.
*/
void reshape( int w, int h )
{
// Dimensionar la ventana de acuerdo a las nuevas medidas:
	glViewport( 0, 0, (GLsizei) w, (GLsizei) h );
// Activar el modo de proyecci�n:
	glMatrixMode( GL_PROJECTION );
// Cargar la matriz identidad en la matriz actual de proyecci�n:
	glLoadIdentity();
// Ajustar el frustum a las nuevas medidas:
	if( w <= h )
	{
		glOrtho(- 1.5, 
				  1.5, 
				- 1.5 * (GLfloat)h / (GLfloat)w,
				  1.5 * (GLfloat)h / (GLfloat)w,
				-10.0,
				 10.0							);
	}
	else
	{
	    glOrtho(- 1.5 * (GLfloat)w / (GLfloat)h,
				  1.5 * (GLfloat)w / (GLfloat)h,
			    - 1.5,
				  1.5,
			    -10.0,
			     10.0							);
	}
// Activar el modo de Modelo-Vista:
	glMatrixMode( GL_MODELVIEW );
// Cargar la matriz identidad en la matriz actual de modelo-vista:
	glLoadIdentity();
}
//
//----------------------------------------------------------------------------------------------
//
/*
	Funci�n principal.
	Inicializa GLUT y ejecuta la rutina de despliegue.
*/
int main( int argc, char** argv )
{
// Inicializar GLUT:
	glutInit( &argc, argv );
// Inicializar modo de despliegue, usar 2 buffers, usar 3 canales
// de color, y usar el buffer de profundidad:
	glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH );
// Inicializar el tama�o de la ventana:
	glutInitWindowSize( 500, 500 );
// Inicializar la posici�n de la ventana:
	glutInitWindowPosition( 100, 100 );
// Desplegar la ventana (El t�tulo es el primer argumento recibido,
// es decir, el 'path' del archivo ejecutable para este programa):
	glutCreateWindow( argv[0] );
// Ejecutar la funci�n 'init':
	init();
// Registrar 'callbacks':
	glutDisplayFunc( display ); 
	glutReshapeFunc( reshape );
	glutIdleFunc( idle );
// Inicia render:
	glutMainLoop();
// ANSI C requiere el retorno de un entero, generalmente
// 0 si todo sali� bien, y otro entero si hay error.
	return 0;
}
//
//----------------------------------------------------------------------------------------------
//
