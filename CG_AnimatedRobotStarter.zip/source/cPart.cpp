#include "cPart.h"

Part::Part(float _r, float _g, float _b)
{
	r = _r;
	g = _g;
	b = _b;
}

Part::~Part()
{
}

void Part::draw()
{
	glPushMatrix();
	{
		glColor3f(r, g, b);
		glutSolidCube(1);
	}
	glPopMatrix();
}

void Part::update()
{

}




