#include "cRobot.h"

Robot::Robot()
{
	for (int i = 0; i < ROBOTPARTS; i++)
	{
		parts[i] = new Part(1, 1, 1);
		rotX[i] = 0.0f;
	}
	parts[HEAD]->r = 1;
	parts[HEAD]->g = 0;
	parts[HEAD]->b = 0;

}

Robot::~Robot()
{
}

void Robot::draw()
{
	glPushMatrix();
	{
		parts[BODY]->draw();	// cube, side 1
		glPushMatrix();
		{
			//glRotatef(rotY[NECK], 0, 1, 0);
			glTranslated(0, 0.5, 0);
			glPushMatrix();
			{
				glScalef(0.2, 0.1, 0.2);
				parts[NECK]->draw();
			}
			glPopMatrix();
			glTranslatef(0, 0.25, 0);
			glScalef(0.5f, 0.5f, 0.5f);
			parts[HEAD]->draw();
		}
		glPopMatrix();

	}
	glPopMatrix();
}

void Robot::update()
{

}