#pragma once
#ifdef __APPLE__
// See: http://lnx.cx/docs/opengl-in-xcode/
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#include <GLUT/glut.h>
#include <stdlib.h>
#else
#include "freeglut.h"
#endif
#include <stdio.h>
#include <math.h>

#include "cPart.h"

#ifndef ROBOTPARTS
	#define ROBOTPARTS 18
#endif

enum RobotPart {
	BODY,
	NECK,
	HEAD,
	HIP,
	LSHOULDER,
	LFOREARM,
	LARM,
	LHAND,
	LTHIGH,
	LLEG,
	LFOOT,
	RSHOULDER,
	RFOREARM,
	RARM,
	RHAND,
	RTHIGH,
	RLEG,
	RFOOT
};

class Robot
{
public:
	Robot();
	~Robot();

	void draw();
	void update();

	float rotX[ROBOTPARTS];
	float rotYbody;
	Part* parts[ROBOTPARTS];
};

