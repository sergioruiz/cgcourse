/*
 * Sergio Ruiz.
 *
 * TC3022. Computer Graphics Course.
 * Basic template OpenGL project.
 * Illumination.
 */

#pragma once

#ifndef __POINT
#define __POINT
class Point
{
public:
	Point(float _x, float _y, float _z);
	~Point();

	float x;
	float y;
	float z;
};
#endif //__POINT
