/*
 * Sergio Ruiz.
 *
 * TC3022. Computer Graphics Course.
 * Basic template OpenGL project.
 * Illumination.
 */

#pragma once

#ifdef __APPLE__
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#include <GLUT/glut.h>
#else
#include "freeglut.h"
#include <stdio.h>
#include <math.h>
#endif
#include "cPoint.h"

#ifndef __TRIANGLE
#define __TRIANGLE
class Triangle
{
public:
	Triangle(Point* _A, Point* _B, Point* _C);
	~Triangle();

	void draw();
	void update();

	// Pointers (memory addresses) to objects of type Point:
	Point*		A;
	Point*		B;
	Point*		C;

	// 4 arrays of floats to store material properties,
	// The arrays don't have a size yet:
	GLfloat*	mat_ambient;
	GLfloat*	mat_diffuse;
	GLfloat*	mat_specular;
	GLfloat*	mat_shininess;
};
#endif //__TRIANGLE
