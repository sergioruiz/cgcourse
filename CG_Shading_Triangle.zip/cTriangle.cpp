/*
 * Sergio Ruiz.
 *
 * TC3022. Computer Graphics Course.
 * Basic template OpenGL project.
 * Illumination.
 */

#include "cTriangle.h"

Triangle::Triangle(Point* _A, Point* _B, Point* _C)
{
	A = _A;
	B = _B;
	C = _C;

	// To-Do: initialize materials:

}

Triangle::~Triangle()
{
	delete A;
	delete B;
	delete C;
}

void Triangle::draw()
{
	glPushMatrix();
	{
		// To-Do: draw with materials instead of colors:

		glBegin(GL_POLYGON);
		{
			glVertex3f(A->x, A->y, A->z);
			glVertex3f(B->x, B->y, B->z);
			glVertex3f(C->x, C->y, C->z);
		}
		glEnd();
	}
	glPopMatrix();
}

void Triangle::update()
{

}
