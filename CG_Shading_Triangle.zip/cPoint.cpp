/*
 * Sergio Ruiz.
 *
 * TC3022. Computer Graphics Course.
 * Basic template OpenGL project.
 * Illumination.
 */

#include "cPoint.h"

Point::Point(float _x, float _y, float _z)
{
	x = _x;
	y = _y;
	z = _z;
}

Point::~Point()
{
}
